# Проект: Место

### Обзор

* Figma
* Картинки

**Figma**

* [Ссылка на макет в Figma](https://www.figma.com/file/2cn9N9jSkmxD84oJik7xL7/JavaScript.-Sprint-4?node-id=0%3A1)

Ссылка на github pages: https://uberdealstrasse.github.io/mesto/